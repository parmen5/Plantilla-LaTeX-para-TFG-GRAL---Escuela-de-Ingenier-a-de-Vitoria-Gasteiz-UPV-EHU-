# Gradu Amaierako Lanaren (GRAL) memoriarako txantiloia

Gasteizko Ingeniaritza Eskolako (UPV/EHU) araudia eta [UPV/EHUren marka adierazteko gida](https://www.ehu.eus/documents/10136/3950780/GUIA_EXPRESION_UPV_es.pdf/4d538337-2577-4260-ae02-d0fed29a26b5) jarraituz Gradu Amaierako Lana sortzeko txantiloia.

> [!IMPORTANT]
> XeLaTeX konpilatzaile gisa erabiltzea gomendatzen da, iturri ofizialak recte karga daitezen.

## Azala pertsonalizatzea

`main.tex` fitxategian GRALaren azaleko datuak sartu behar dira:

```latex
% ------------------------------------------------------------ %
% DOKUMENTUAREN DATUAK                                         %
% ------------------------------------------------------------ %

% Izenburua:
\newcommand{\titulo}{<Lanaren izenburua>}
% Ikasturtea:
\newcommand{\curso}{<XXXX-XXXX>}
% Gradua:
\newcommand{\carrera}{XXXXXXXX Gradua}
% Ikaslea:
\newcommand{\alumno}{<1. abizena, 2. abizena, izena>}
% GRALaren 1. zuzendaria:
\newcommand{\direccionA}{<1. abizena, 2. abizena, izena>}
% GRALaren 2. zuzendaria (ez badago, iruzkindu lerro hau hemen eta baita preamble.tex fitxategian ere):
\newcommand{\direccionB}{<1. abizena, 2. abizena, izena>}
% Data:
\newcommand{\fecha}{<XXXX(e)ko hilaren eguna, urtea>}
% ------------------------------------------------------------ %